# PWFramework
This is an gameplay framework implementation for Unity.  
This ptoject includes PWGame, an example game that that uses framework. 

PW Is short for "Professor Walek"
 
AS this is a project being worked on... 
Please contact me before you use it, I likely have things to tell you that will help you. 

Written by Gregory "Grash" Walek 
email grashuriza(at)gmail(dot)com

This project is licensed under MIT License. See license document for more info. 