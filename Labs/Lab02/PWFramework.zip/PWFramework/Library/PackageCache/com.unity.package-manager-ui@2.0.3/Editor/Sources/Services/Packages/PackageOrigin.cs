﻿namespace UnityEditor.PackageManager.UI
{
    internal enum PackageOrigin
    {
        Unknown,
        Builtin,
        Registry
    }
}